package com.lenis0012.bukkit.loginsecurity.modules.general;

public enum LocationMode {
    DEFAULT,
    SPAWN,
    RANDOM
}
