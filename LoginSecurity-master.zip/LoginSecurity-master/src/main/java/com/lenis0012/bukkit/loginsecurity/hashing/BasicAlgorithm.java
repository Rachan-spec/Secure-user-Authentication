package com.lenis0012.bukkit.loginsecurity.hashing;

/**
 * @deprecated Use {@link HashFunction}
 */
@Deprecated
public abstract class BasicAlgorithm implements HashFunction {
}
