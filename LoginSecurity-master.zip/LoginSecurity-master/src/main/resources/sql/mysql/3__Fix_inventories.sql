ALTER TABLE ls_inventories MODIFY contents MEDIUMTEXT;
ALTER TABLE ls_inventories MODIFY helmet TEXT;
ALTER TABLE ls_inventories MODIFY chestplate TEXT;
ALTER TABLE ls_inventories MODIFY leggings TEXT;
ALTER TABLE ls_inventories MODIFY boots TEXT;
ALTER TABLE ls_inventories MODIFY off_hand TEXT;