CREATE INDEX idx_ls_players_last_name ON ls_players (last_name);
